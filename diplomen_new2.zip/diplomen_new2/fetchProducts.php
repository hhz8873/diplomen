<?php
ob_start();
session_start();
include("database.php");
include("navbar.php");
// Connection to the database
$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

// Check for connection error
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch all products
$query = "SELECT * FROM products";
$result = $conn->query($query);

//Query to search products
$searchTerm = isset($_GET['search']) ? $_GET['search'] : null;
if ($searchTerm) {
    // Use prepared statements to avoid SQL injection
    $query = "SELECT * FROM products WHERE productName LIKE ?";
    $stmt = $conn->prepare($query);
    $likeSearchTerm = "%$searchTerm%";
    $stmt->bind_param("s", $likeSearchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $query = "SELECT * FROM products";
    $result = $conn->query($query);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productName = $_POST['productName'];
    $productImage = $_POST['productImage'];
    $productDescription = $_POST['productDescription'];
    $productUsage = $_POST['productUsage'];
    $productType = $_POST['productType'];
    $studyRating = $_POST['studyRating'];
    $effectivenessRating = $_POST['effectivenessRating'];

    $query = "INSERT INTO products (productName, productImage, productDescription, productUsage, productType, studyRating, effectivenessRating) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssid", $productName, $productImage, $productDescription, $productUsage, $productType, $studyRating, $effectivenessRating);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Продуктът е добавен успешно!');</script>";
    } else {
        echo "<script>alert('Грешка при добавянето на продукта!');</script> " . $conn->error;
    }
    $stmt->close();
    $conn->close();
}
// Start output buffer
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" rel="stylesheet"/>
<title>Product Details</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<style>
  body{
    overflow-x: hidden;
  }
       :root{
    --primary-color:#f92524;
    --primary-color-dark:#e91a1a;
    --secondary-color:#faf9fe;
    --text-dark:#0f172a;
    --text-light:#64748b;
    --white:#ffffff;
    --max-width: 1200px;
        }
        .product-form {
            background-color: var(--white);
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 4px;
            border: 1px solid var(--text-light);
        }

        .form-group button {
            display: inline-block;
            padding: 10px 15px;
            background-color: var(--primary-color);
            color: var(--white);
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: var(--primary-color-dark);
        }
        .modal-backdrop {
        display: none !important;
        }
</style>
</head>
<body>
    <br><br><br><br>
    <div class="search-container" style="text-align: center; margin: 20px; width:300px; display:block; margin:0 auto;">
    <form action="" method="GET">
        <input style=" border:#0f172a solid thin; border-radius:10px" type="text" name="search" placeholder="Потърси за продукт..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button type="submit" style="margin-bottom: 5%;">Потърси</button>
    </form>
</div>

<!-- Button to Open Modal -->
<button type="button"  data-toggle="modal" data-target="#addProductModal" style="display:block; margin: 0 auto;">
  Добави продукт
</button>

<!-- Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1" role="dialog" aria-labelledby="addProductModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addProductModalLabel">Нов продукт</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="post">
          <div class="form-group">
            Име на продукта: <input type="text" name="productName" required>
          </div>
          <div class="form-group">
            Изображение на продукта: <input type="text" name="productImage" required>
          </div>
          <div class="form-group">
            Описание на продукта: <textarea name="productDescription" required></textarea>
          </div>
          <div class="form-group">
            Употреба на продукта: <input type="text" name="productUsage" required>
          </div>
          <div class="form-group">
            Тип на продукта: <select name="productType" required>
              <option value="diet">Диета</option>
              <option value="additive">Добавка</option>
            </select>
          </div>
          <div class="form-group">
            Оценка на изученост: <input type="number" name="studyRating" required>
          </div>
          <div class="form-group">
            Оценка на ефективност: <input type="number" name="effectivenessRating" required>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary">Добави продукт</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="section_container">
<?php
// Generate a form for each product
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='product-form'>";
        echo "<form action='updateProducts.php' method='post'>";
        echo "<div class='form-group'><input type='hidden' name='id' value='".$row["id"]."'></div>";
        echo "<div class='form-group'>Име на продукта: <input type='text' name='productName' value='".$row["productName"]."'></div>";
        echo "<div class='form-group'>Изображение на продукта: <input type='text' name='productImage' value='".$row["productImage"]."'></div>";
        echo "<div class='form-group'>Описание на продукта: <textarea name='productDescription'>".$row["productDescription"]."</textarea></div>";
        echo "<div class='form-group'>Употреба на продукта: <input type='text' name='productUsage' value='".$row["productUsage"]."'></div>";
        echo "<div class='form-group'>Тип на продукта: <select name='productType'>
                <option value='diet'" . ($row["productType"] == 'diet' ? ' selected' : '') . ">Диета</option>
                <option value='additive'" . ($row["productType"] == 'additive' ? ' selected' : '') . ">Добавка</option>
              </select></div>";
        echo "<div class='form-group'>Оценка на изученост: <input type='number' name='studyRating' value='".$row["studyRating"]."'></div>";
        echo "<div class='form-group'>Оценка на ефективност: <input type='number' name='effectivenessRating' value='".$row["effectivenessRating"]."'></div>";
        echo "<div class='form-group'><button type='submit'>Редактирай продукта</button></div>";
       
        echo "</form>";
        echo "</div>"; // Close product-form
        echo "<hr>";
    }
} else {
    echo "<p>Няма намерени продукти.</p>";
}


?>
</div> <!-- Close section_container -->

</body>
</html>
<?php
// Flush the output buffer
ob_end_flush();
?>
