<?php
session_start();
// Унищожаване на всички сесии
session_destroy();
// Редирект към началната страница
header('Location: index.php');
exit;
?>
