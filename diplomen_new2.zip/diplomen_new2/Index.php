<?php 
session_start();
include("database.php");
include("portfolio.php");
include("navbar.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link  href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js" rel="stylesheet"/>
  	<title>Sport Endurance</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<style>
    .about_content {
    margin-bottom: 20px;
    padding: 20px;
    background-color: #f8f9fa;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: calc(25% - 40px); /* Adjusted width for four sections in a row */
    margin-right: 20px; /* Margin between each section */
    float: left; /* Float to make them inline */
    }
    .about_header {
    font-size: 24px;
    margin-bottom: 10px;
    }
          body{
    overflow-x: hidden;
          }
    .about_bg {
    width: 100%;
    max-width: 100%;
    height: auto;
    margin-bottom: 10px;
    }
    .button_container {
    text-align: center;
    }
    .section_container::after {
    content: "";
    display: table;
    clear: both;}
</style>
    </head>
<body>
    <header class="header">
       <div class="section_container header_container" id="home">
            <div class="header_image">
                <img src="Images/Index/Header.png" alt="header" style="width: 600px; margin-left:-40%"/>
            </div>
            <div class="header_content">
                <h4>Изгради тялото си и</h4>
                <h1 class="section_header">оформи себе си</h1>
                <p>
                    Разгърни потенциала си и започни пътуване към едно по-силно,
                    по-стройно и по-уверено теб. 
                </p>
                <p>
                    Нашата цел е да те напътстваме през нашата
                    обширна програма, изградена специално за твоите фитнес цели.
                </p>
                <div class="header_btn">
                   <a href="DietPage.php"><button class="btn" style="width:180px">Избери си диета!</button></a> 
                </div>
            </div>
       </div>
    </header>

    <section class="section_container about_container" id="about">
    <div class="about_content">
    <h2 class="about_header">Какво е протеинът?</h2>
    <img class="about_bg" src="Images/BlogPosts/Protein.jpeg" alt="bg" style="max-width: 100%;">
    <div class="button_container">
    <a href="blog_page.php?blog_id=1"><button class="btn">Научи повече!</button></a>
    </div>
</div>       
<div class="about_content">
    <h2 class="about_header">Нуждаем ли се от креатин?</h2>
    <img class="about_bg" src="Images/BlogPosts/Creatine.jpeg" alt="bg">
    <div class="button_container">
    <a href="blog_page.php?blog_id=2"><button class="btn">Научи повече!</button></a>
    </div>
</div> 
<div class="about_content">
    <h2 class="about_header">Работят ли аминокиселините?</h2>
    <img class="about_bg" src="Images/BlogPosts/BCAA.jpeg" alt="bg">
    <div class="button_container">
    <a href="blog_page.php?blog_id=3"><button class="btn">Научи повече!</button></a>
    </div>
</div> 
<div class="about_content">
    <h2 class="about_header"> Ашваганда, откъде идва?</h2>
    <img class="about_bg" src="Images/BlogPosts/Ashwagandha.jpeg" alt="bg">
    <div class="button_container">
    <a href="blog_page.php?blog_id=4"><button class="btn">Научи повече!</button></a>
    </div>
</div> 
    </section>
</body>
</html> 
<?php 
include("footer.php");
?>