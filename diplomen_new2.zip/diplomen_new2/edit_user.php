<?php
include("database.php");
include("navbar.php");
$userMessage = "";

// Check if there's a POST request to update user data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    // Sanitize input data
    $userId = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING); // Add password field
    $role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING); // Add role field

    // Update user information in the database
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
    $sql = "UPDATE accounts SET username=?, email=?, password=?, role=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssssi", $username, $email, $password, $role, $userId);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    if ($result) {
        $userMessage = "Потребителските данни са редактирани";
        // Redirect or display a success message
        echo '<meta http-equiv="refresh" content="3;url=manage-users.php">';
    } else {
        $userMessage = "Грешка при редакцията.";
    }
}

// Check if the user ID is present in the URL for fetching user information
if (isset($_GET['id'])) {
    $userId = $_GET['id'];

    // Fetch user information for editing
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
    $sql = "SELECT * FROM accounts WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result); // Fetch user data
    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    // If user is not found and there is no update message, display "User not found" message
    if (!$user && empty($userMessage)) {
        $userMessage = "User not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" rel="stylesheet"/>
  	<title>Sport Endurance</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">

    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>
        :root {
            --primary-color: #f92524;
            --primary-color-dark: #e91a1a;
            --secondary-color: #faf9fe;
            --text-dark: #0f172a;
            --text-light: #64748b;
            --white: #ffffff;
            --max-width: 600px;
        }

        body {
            overflow-x: hidden;
            font-family: "Poppins", sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-dark);
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: var(--max-width);
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            color: var(--primary-color);
            text-align: center;
        }

        form {
            background-color: var(--white);
            padding: 20px;
            border-radius: 10px;
            border: 1px solid var(--primary-color);
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid var(--text-light);
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: var(--primary-color-dark);
        }
    </style>
</head>
<body>
    <br><br><br><br>
<div class="container">
    <h1><strong>Редактирай потребител</strong></h1>
    <?php if(isset($user)): ?>
    <form action="edit_user.php" method="post">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">
        <label for="username">Потребителско име:</label>
        <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($user['username']); ?>">
        <label for="email">Имейл:</label>
        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>">
        <label for="password">Парола:</label> <!-- Add password field -->
        <input type="password" name="password" id="password" style="border: black solid thin;">
        <label for="role">Роля:</label> <!-- Add role field -->
        <select name="role" id="role">
            <option value="user" <?php if($user['role'] === 'user') echo 'selected'; ?>>Потребител</option>
            <option value="admin" <?php if($user['role'] === 'admin') echo 'selected'; ?>>Админ</option>
        </select>
        <!-- Add additional fields as needed -->
        <button type="submit" style="margin-left: 3%;">Запази промени</button>
    </form>
    <?php else: ?>
    <p><?php echo $userMessage; ?></p>
    <?php endif; ?>
</div>
</body>
</html>
<br><br>
<?php 
include("footer.php");
?>