<?php 
ob_start();
session_start();
include("database.php");
include("navbar.php");
// Placeholder for handling form submissions

$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
if (isset($_POST['login'])) {
        // Handle login
        $username = $conn->real_escape_string(trim($_POST['username']));
        $password = $conn->real_escape_string(trim($_POST['password']));

        $sql = "SELECT * FROM accounts WHERE username='$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (md5($password) === $row['password']) { // Сравнение на хешираната парола
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['role'] = $row['role'];
                header('Location: index.php');
                exit;            
            } else {
                echo "Грешна парола.";
            }
        } else {
            echo "Акаунтът не съществува.";
        }
    } elseif (isset($_POST['register'])) {
        // Handle registration
        $username = $conn->real_escape_string(trim($_POST['username']));
        $email = $conn->real_escape_string(trim($_POST['email']));
        $password = $conn->real_escape_string(trim($_POST['password']));
        $role = 'user';

        $hashedPassword = md5($password); // Използване на md5 за хеширане на паролата

        $stmt = $conn->prepare("INSERT INTO accounts (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $email, $hashedPassword, $role);

        if ($stmt->execute()) {
            echo "Registration successful!";
            // Optionally, redirect to login page or elsewhere
            // header("Location: login.php");
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }


$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" rel="stylesheet"/>
<title>Product Details</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="styleproduct.css" >
<style>
          body{
    overflow-x: hidden;
  }
    </style>
</head>
<body>
<br><br><br><br><br><br>
<div id="auth-container">
<div class="form-container login-container">
        <form action="" method="post">
            <h2>Вход в профил</h2>
            <div class="input-group">
                <input type="text" name="username" placeholder="Потребителско име" required style="border: black solid thin;">
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Парола" required style="border: black solid thin;">
            </div>
            <button type="submit" name="login" class="btn">Вход</button>
            <p class="switch-form">Нямаш профил? <a href="#register">Регистрирай се</a></p>
        </form>
    </div>
    
    <!-- Registration Form -->
    <div class="form-container register-container" style="display:none;">
        <form action="" method="post">
            <h2>Регистрация на профил</h2>
            <div class="input-group">
                <input type="text" name="username" placeholder="Потребителско име" required style="border: black solid thin;">
            </div>
            <div class="input-group">
                <input type="email" name="email" placeholder="Имейл" required style="border: black solid thin;">
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Парола" required style="border: black solid thin;">
            </div>
            <button type="submit" name="register" class="btn">Регистрирай</button>
            <p class="switch-form">Вече имаш профил? <a href="#login">Вход</a></p>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle to Registration Form
    document.querySelector('.switch-form a[href="#register"]').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent the default anchor action
        document.querySelector('.login-container').style.display = 'none'; // Hide the login form
        document.querySelector('.register-container').style.display = 'block'; // Show the registration form
    });

    // Toggle to Login Form
    document.querySelector('.switch-form a[href="#login"]').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent the default anchor action
        document.querySelector('.register-container').style.display = 'none'; // Hide the registration form
        document.querySelector('.login-container').style.display = 'block'; // Show the login form
    });
});
</script>
</body>
</html>
<br><br>
<?php 
include("footer.php");
?>