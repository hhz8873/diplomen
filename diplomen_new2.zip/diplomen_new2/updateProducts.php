<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assume $_POST['id'] is sent with the form data
    $id = $_POST['id'] ?? null;
    $productName = $_POST['productName'] ?? '';
    $productImage = $_POST['productImage'] ?? '';
    $productDescription = $_POST['productDescription'] ?? '';
    $productRating = $_POST['productRating'] ?? 0;
    $productUsage = $_POST['productUsage'] ?? '';
    $productType = $_POST['productType'] ?? '';
    $studyRating = $_POST['studyRating'] ?? null; // Ensure these can accept null if not filled
    $effectivenessRating = $_POST['effectivenessRating'] ?? null;

    include("database.php");
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
    
    if (!$conn) {
        // Connection failed
        echo "Connection failed: " . mysqli_connect_error();
        exit();
    }

    // Prepare the update statement
    $query = "UPDATE products SET productName=?, productImage=?, productDescription=?, productRating=?, productUsage=?, productType=?, studyRating=?, effectivenessRating=? WHERE id=?";
    
    if ($stmt = $conn->prepare($query)) {
        // Bind parameters and execute
        $stmt->bind_param("sssssssii", $productName, $productImage, $productDescription, $productRating, $productUsage, $productType, $studyRating, $effectivenessRating, $id);

        if ($stmt->execute()) {
            // Redirect or output success message
            header("Location: " . $_SERVER['HTTP_REFERER']); 
            exit();
        } else {
            // Handle execution error
            echo "Execute failed: " . $stmt->error;
        }

        $stmt->close();
    } else {
        // Handle preparation error
        echo "Prepare failed: " . $conn->error;
    }

    $conn->close();
} else {
    // Not a POST request
    echo "Invalid request method.";
}
?>
