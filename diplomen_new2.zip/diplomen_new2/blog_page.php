<?php
session_start();
include("database.php");
include("navbar.php");

$blogFound = false;
$blog_image = $blog_title = $blog_text = '';

// Check for blog_id in the URL
if (isset($_GET['blog_id'])) {
    $blog_id = $_GET['blog_id'];
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

    if ($conn) {
        $sql = "SELECT * FROM blog_posts WHERE id = $blog_id";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $blog_image = $row['blog_image'];
            $blog_title = $row['blog_title'];
            $blog_text = $row['blog_text'];
            $blogFound = true;
        } else {
            $blogFound = false;
            $error_message = "Blog not found";
        }
        mysqli_close($conn);
    } else {
        $error_message = "Invalid blog ID";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link  href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js" rel="stylesheet"/>
  	<title>Sport Endurance</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="comments.css">


    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>
        :root {
            --primary-color: #f92524;
            --primary-color-dark: #e91a1a;
            --secondary-color: #faf9fe;
            --text-dark: #0f172a;
            --text-light: #64748b;
            --white: #ffffff;
        }

        body {
            overflow-x: hidden;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-dark);
            margin: 0;
        }

        .container1 {
            background-color: var(--white);
            border-radius: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: auto;
            width: 80%;
            max-width: 800px;
        }

        .blog_img {
            max-width: 100%;
            height: auto;
            border-radius: 49px 50px 50px 50px;
        }

        h2 {
            color: var(--primary-color);
        }

        p {
            color: var(--text-light);
        }
    </style>
</head>
<body>
    <br><br><br><br>
    <?php if ($blogFound): ?>
        <div class="container1">
            <?php echo "<div style='border: radius 10px; width:450px; display: block; margin:0 auto;' class='blog_img'><img src='Images/BlogPosts/" . htmlspecialchars($blog_image) . "' alt='" . htmlspecialchars($blog_title) . "' ></div>"; ?>
            <br>
            <h2><?php echo $blog_title; ?></h2>
            <p><?php echo $blog_text; ?></p>
        </div>
        <br><br><br>
    <?php else: ?>
        <p><?php echo $error_message; ?></p>
    <?php endif; ?>

    <div class="comments"></div>

<br>

</body>
</html>    
<?php include("footer.php"); ?>
<script>
const comments_page_id = <?php echo $blog_id; ?>;

// Function to bind events to newly loaded comments and forms
function bindCommentEvents() {
    // Handle clicks on 'Write Comment' and 'Reply' buttons
    document.querySelectorAll(".comments .write_comment_btn, .comments .reply_comment_btn").forEach(element => {
        element.onclick = event => {
            event.preventDefault();
            document.querySelectorAll(".comments .write_comment").forEach(element => element.style.display = 'none');
            const formContainer = document.querySelector("div[data-comment-id='" + element.getAttribute("data-comment-id") + "']");
            if (formContainer) {
                formContainer.style.display = 'block';
                formContainer.querySelector("input[name='name']").focus();
            }
        };
    });

    // Handle form submissions
    document.querySelectorAll(".comments .write_comment form").forEach(element => {
        element.onsubmit = event => {
            event.preventDefault();
            const formData = new FormData(element);
            formData.append('page_id', comments_page_id); // Ensure page_id is included in the POST request

            fetch("comments.php?page_id=" + comments_page_id, {
                method: 'POST',
                body: formData
            }).then(response => response.text()).then(data => {
                element.parentElement.innerHTML = data;
                bindCommentEvents(); // Re-bind events to new content
            });
        };
    });
}

// Initial fetch to load comments
fetch("comments.php?page_id=" + comments_page_id)
    .then(response => response.text())
    .then(data => {
        document.querySelector(".comments").innerHTML = data;
        bindCommentEvents(); // Bind events after initial content load
    });
</script>
