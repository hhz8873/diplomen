<?php   
ob_start(); // Start output buffering
session_start();
include("database.php");
include("navbar.php");
  


// Check if the form is submitted
if (isset($_POST['addToPortfolio']) && isset($_SESSION['user_id'])) {
    // Retrieve form data
    $userId = $_SESSION['user_id']; // Assuming you've stored user_id in session on login
    $calories = filter_input(INPUT_POST, 'calories', FILTER_VALIDATE_FLOAT); // Get the calculated calories

    // Database update logic
    if ($calories && $userId) {
        $conn = new mysqli($db_server, $db_user, $db_pass, $db_name);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "UPDATE accounts SET calories = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("di", $calories, $userId);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                echo "<script>alert('Калориите са добавени успешно към портфолиото.');</script>";
                header("Location: index.php");
                exit(); // Ensure no further code is executed after redirection
            } else {
                echo "<script>alert('Не бяха направени промени по портфолиото ти.');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Грешка!.');</script>";
        }
        $conn->close();
    } else {
        echo "<script>alert('Грешка!.');</script>";
    }
}

// Проверка за администратор
$is_admin = false; // По подразбиране не е администратор
if (isset($_SESSION['admin']) && $_SESSION['admin'] == true) {
    $is_admin = true; // Ако потребителят е администратор, задаваме променливата на true
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<style>
          body{
    overflow-x: hidden;
  }
    </style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" rel="stylesheet"/>
  	<title>Sport Endurance</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="stylePage.css">
    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>
        :root{
            --primary-color: #f92524;
            --primary-color-dark: #e91a1a;
            --secondary-color: #faf9fe;
            --text-dark: #0f172a;
            --text-light: #64748b;
            --white: #ffffff;
            --max-width: 600px;
        }
        body {
            font-family: "Poppins", sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-dark);
            margin: 0;
            padding: 0;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin-left: 1%;
        }
        .calculator {
            margin-left: 1%;
            margin-right: 2%;
            background-color: var(--white);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .calculator input[type="number"],
        .calculator select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid var(--text-light);
            border-radius: 5px;
            box-sizing: border-box;
        }
        .calculator button {
            width: 100%;
            padding: 10px;
            background-color: var(--primary-color);
            color: var(--white);
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 1%;
        }
        .calculator button:hover {
            background-color: var(--primary-color-dark);
        }
        .calculator #result {
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<br><br><br><br>
       <div class="calculator">
        <h2><strong>Калориен калкулатор</strong></h2>
        <form id="calorieForm" method="post" action="calcalculator.php">
        <label for="weight">Тегло (кг):</label>
    <input type="number" id="weight" name="weight" placeholder="Въведи своето тегло в килограми">
    <label for="height">Височина (см):</label>
    <input type="number" id="height" name="height" placeholder="Въведи своята височина в сантиметри">
    <label for="age">Възраст (години):</label>
    <input type="number" id="age" name="age" placeholder="Въведи своята възраст в години">
    <label for="gender">Пол:</label>
    <select id="gender" name="gender">
        <option value="male">Мъж</option>
        <option value="female">Жена</option>
    </select>
    <label for="activity">Ниво на активност:</label>
    <select id="activity" name="activity">
        <option value="sedentary">Ниска активност (ниска или никаква)</option>
        <option value="lightly-active">Лека активност (спорт 1-3 дни в седмицата)</option>
        <option value="moderately-active">Moderately Active (спорт 3-5 дни в седмицата)</option>
        <option value="very-active">Висока активност (спорт 6-7 дни в седмицата)</option>
        <option value="extra-active">Изключително висока активност (ежедневен спорт и друго натоварване)</option>
    </select>
    <label for="goal">Цел:</label>
    <select id="goal" name="goal">
        <option value="deficit">Калориен дефицит</option>
        <option value="surplus">Калориен излишък</option>
        <option value="maintenance">Поддъражане на тегло</option>
    </select>
        <input type="hidden" id="calories" name="calories">
        <div id="result"></div>
        <input style="display: block; margin: 0 auto;" type="submit" name="addToPortfolio" value="Добави в портфолио">
        </form>
        <button onclick="calculateCalories()">Калкулирай калории</button>
    </div>
    
    <script>
        function calculateCalories() {
            const weight = document.getElementById('weight').value;
            const height = document.getElementById('height').value;
            const age = document.getElementById('age').value;
            const gender = document.getElementById('gender').value;
            const activity = document.getElementById('activity').value;
            const goal = document.getElementById('goal').value;

            // Check if any of the input fields are empty
            if (!weight || !height || !age) {
                document.getElementById('result').innerText = 'Моля попълнете всички полета.';
                return;
            }

            let bmr;
            if (gender === 'male') {
                bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
            } else {
                bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
            }

            let calories;
            switch (activity) {
                case 'sedentary':
                    calories = bmr * 1.2;
                    break;
                case 'lightly-active':
                    calories = bmr * 1.375;
                    break;
                case 'moderately-active':
                    calories = bmr * 1.55;
                    break;
                case 'very-active':
                    calories = bmr * 1.725;
                    break;
                case 'extra-active':
                    calories = bmr * 1.9;
                    break;
                default:
                    calories = bmr;
            }

            if (goal === 'deficit') {
                calories -= 500; // 500 calorie deficit
            } else if (goal === 'surplus') {
                calories += 500; // 500 calorie surplus
            }

            document.getElementById('result').innerText = `Ежедневните ти калориини нужди са приблизително ${calories.toFixed(2)} калории.`;
            document.getElementById('calories').value = calories.toFixed(2);
            document.getElementById('result').innerText = `Ежедневните ти калориини нужди са приблизително ${calories.toFixed(2)} калории.`;
        }

        
    </script>

</body>
</html>
<br><br><br>
<?php 
include("footer.php");
?>