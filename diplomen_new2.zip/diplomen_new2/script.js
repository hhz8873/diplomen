const menuBtn = document.getElementById( "menu-btn" );
const navLinks = document.getElementById( "nav-links" );
const menuBtnIcon = menuBtn.querySelector( "i" );
menuBtn.addEventListener( "click", (e) => {
    navLinks.classList.toggle("open")

    const isOpen = navLinks.classList.contains("open");
    menuBtnIcon.setAttribute("class", isOpen?"ri-close-line":"ri-menu-line")
});

navLinks.addEventListener("click", (e)=>{
    navLinks.classList.remove("open")
    menuBtnIcon.setAttribute("class", "ri-menu-line");
});

const scrollRevealOption = {
    distance: "50px",
    origin:"bottom",
    duration: 1000,
};

ScrollReveal().reveal(".header_image img", {
    ...scrollRevealOption,
});

ScrollReveal().reveal(".header_container h4, .header_container h1, .header_container .section_header", {
    ...scrollRevealOption,
    delay: 250,
});

ScrollReveal().reveal(".header_container p", {
    ...scrollRevealOption,
    delay: 500,
});

ScrollReveal().reveal(".header_btn", {
    ...scrollRevealOption,
    delay: 750,
});

// Get the modal
var loginModal = document.getElementById("loginModal");
var registerModal = document.getElementById("registerModal");

// Get the button that opens the modal
var loginBtn = document.getElementById("loginBtn");
var registerBtn = document.getElementById("registerBtn");

// Get the <span> element that closes the modal
var spans = document.getElementsByClassName("close");

// When the user clicks the button, open the modal 
loginBtn.onclick = function() {
  loginModal.style.display = "block";
}
registerBtn.onclick = function() {
  registerModal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
for (let span of spans) {
  span.onclick = function() {
    loginModal.style.display = "none";
    registerModal.style.display = "none";
  }
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == loginModal || event.target == registerModal) {
    loginModal.style.display = "none";
    registerModal.style.display = "none";
  }
}
var modal = document.getElementById("modal");
var loginBtn = document.getElementById("loginBtn");
var span = document.getElementsByClassName("close")[0];
var switchToRegister = document.getElementById("switchToRegister");
var switchToLogin = document.getElementById("switchToLogin");
var loginForm = document.getElementById("loginForm");
var registerForm = document.getElementById("registerForm");

loginBtn.onclick = function() {
  modal.style.display = "block";
  loginForm.style.display = "block";
  registerForm.style.display = "none";
}

span.onclick = function() {
  modal.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

switchToRegister.onclick = function() {
  loginForm.style.display = "none";
  registerForm.style.display = "block";
}

switchToLogin.onclick = function() {
  registerForm.style.display = "none";
  loginForm.style.display = "block";
}


document.querySelector('.fa-star').addEventListener('click', function() {
  if(isLoggedIn) {
      var popup = document.getElementById('favoritesPopup');
      popup.style.display = 'block'; // Показваме първо, за да може анимацията да се изпълни
      setTimeout(function() { popup.classList.add('show') }, 10); // Добавяме класа след кратка забавка, за да се стартира анимацията
  } else {
      window.alert("За да продължите трябва да влезете в профила си.");
  }
});

document.querySelector('.favorites-popup .close').addEventListener('click', function() {
  var popup = document.getElementById('favoritesPopup');
  popup.style.display = 'none'; // Скриваме popup-a
  popup.classList.remove('show'); // Премахваме класа, ако е добавен
});
