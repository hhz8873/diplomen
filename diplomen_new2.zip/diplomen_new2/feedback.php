<?php
include("database.php");
include("navbar.php");

// Проверка дали формата е изпратена
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Вземане на данните от формата
    $message = trim($_POST['message']);
    $email = trim($_POST['email']);

    // Връзка към БД
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

    // Проверка за грешка при връзката
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL заявка за вмъкване на запис
    $sql = "INSERT INTO feedback (email, message) VALUES (?, ?)";

    // Подготовка на SQL заявката за изпълнение
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ss", $email, $message);

    function function_alert($message) { 
        echo "<script>alert('$message');</script>"; 
    } 
    if ($stmt->execute()) {
        function_alert("Съобщението ви е изпратено успешно."); 
    } else {
        function_alert("Грешка в избращането на съобщението."); 
    $stmt->close();
    $conn->close();
}}
?>

<!DOCTYPE html>
<html lang="bg">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" rel="stylesheet"/>
  	<title>Sport Endurance</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">

    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>
:root{
    --primary-color:#f92524;
    --primary-color-dark:#e91a1a;
    --secondary-color:#faf9fe;
    --text-dark:#0f172a;
    --text-light:#64748b;
    --white:#ffffff;
    --max-width: 1200px;
}
        body, html {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--secondary-color);
            color: var(--text-dark);
            overflow-x: hidden;
        }

        .feedback-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: var(--white);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-radius: 8px;
            border: 1px solid var(--primary-color);
        }

        .feedback-form h2 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 20px;
        }

        .feedback-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .feedback-form input[type="email"], .feedback-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 1px solid var(--text-light);
            font-family: 'Open Sans', sans-serif;
        }

        .feedback-form button {
            width: 100%;
            padding: 10px 0;
            font-size: 16px;
            background-color: var(--primary-color);
            color: var(--white);
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .feedback-form button:hover {
            background-color: var(--primary-color-dark);
        }
    </style>
</head>
<body>
    <br><br><br><br>
    <div class="feedback-container">
        <form action="feedback.php" method="post" class="feedback-form">
            <h2><strong>Изпрати ни обратна връзка</strong></h2>
            <label for="email">Твоят имейл:</label>
            <input style="width:560px" type="email" id="email" name="email" required>
            <label for="message">Съобщение:</label>
            <textarea style="width:560px" id="message" name="message" rows="4" required></textarea>
            <button type="submit"><strong>Изпрати</strong></button>
        </form>
    </div>
</body>
</html>
<?php 
include("footer.php");
?>
