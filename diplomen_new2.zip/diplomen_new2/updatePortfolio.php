<?php
session_start();
require 'database.php'; // Make sure this file correctly sets up a connection to your database.
$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
// Check if the user is logged in by checking if they have a session called "username" which contains their username.
// Check if the user is logged in and has admin privileges. If not, redirect them to


$diet = isset($_POST['userDiet']) ? mysqli_real_escape_string($conn, $_POST['userDiet']) : '';
$additive = isset($_POST['userAdditive']) ? mysqli_real_escape_string($conn, $_POST['userAdditive']) : '';
$userId = $_SESSION['user_id'];

// Update the diet for the existing user    
if (!empty($diet) && !empty($additive)) {  
    $sql = "UPDATE accounts SET diet= '$diet', additives='$additive' WHERE id='$userId'";
} elseif(!empty($diet)){
    $sql = "UPDATE accounts SET diet= '$diet' WHERE id='$userId'";
} elseif (!empty($additive)) {
    $sql = "UPDATE accounts SET additives='$additive' WHERE id='$userId'";
}

$conn->query($sql);

header("Location: " . $_SERVER['HTTP_REFERER']); 

$conn->close();

?>
