<?php

include("database.php");
// Включване на файл за връзка с базата данни
$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

$is_admin = false; // По подразбиране не е администратор
if (isset($_SESSION['admin']) && $_SESSION['admin'] == true) {
    $is_admin = true; // Ако потребителят е администратор, задаваме променливата на true
}

$calories = "Information not available"; // Съобщение по подразбиране

// Проверка дали потребителят е влязъл в системата
if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Заявка за извличане на калории
    $caloriesQuery = "SELECT calories FROM accounts WHERE id = ?";
    if($stmt = $conn->prepare($caloriesQuery)) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if($row = $result->fetch_assoc()) {
            $calories = htmlspecialchars($row['calories']);
        }
        $stmt->close();
    }
}

// Заявка за избиране на всички продукти с тип 'diet'
$query = "SELECT productName FROM products WHERE productType = 'diet'";
$result = mysqli_query($conn, $query);

// Масив за съхранение на имената на продуктите
$diets = [];
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $diets[] = $row['productName'];
    }
}

// Заявка за избиране на всички продукти с тип 'additive'
$query_additives = "SELECT productName FROM products WHERE productType = 'additive'";
$result_additives = mysqli_query($conn, $query_additives);

// Масив за съхранение на имената на добавките
$additives = [];
if (mysqli_num_rows($result_additives) > 0) {
    while($row = mysqli_fetch_assoc($result_additives)) {
        $additives[] = $row['productName'];
    }
}







?>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('diet').innerText = '<?php echo $currentDiet; ?> калории';
    document.getElementById('additive').innerText = '<?php echo $currentAdditive; ?>';
});
</script>
