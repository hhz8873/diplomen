<?php 
session_start();
include("database.php");
include("navbar.php");


function deleteUser($userId) {
    global $db_server, $db_user, $db_pass, $db_name;
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
    $sql = "DELETE FROM accounts WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}

function fetchUsers() {
    global $db_server, $db_user, $db_pass, $db_name;
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
    $sql = "SELECT * FROM accounts WHERE role = 'user'";
    $result = mysqli_query($conn, $sql);
    mysqli_close($conn);
    return $result;
}

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

if(isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    deleteUser($_GET['id']);
    header('Location: '.$_SERVER['PHP_SELF']); // Redirect to avoid re-deletion on refresh
    exit;
}

$users = fetchUsers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" rel="stylesheet"/>
  	<title>Sport Endurance</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="stylePage.css">
    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>
          body{
    overflow-x: hidden;
  }
    </style>
    <style>
@import url('https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
    :root {
            --primary-color: #f92524;
            --primary-color-dark: #e91a1a;
            --secondary-color: #faf9fe;
            --text-dark: #0f172a;
            --text-light: #64748b;
            --white: #ffffff;
            --max-width: 1200px;
        }

        body {
            font-family: "Poppins", sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-dark);
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: var(--max-width);
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            color: var(--primary-color);
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: var(--primary-color);
            color: var(--white);
        }

        tr:nth-child(even) {
            background-color: var(--white);
        }

        .table-actions a {
            color: var(--primary-color);
            text-decoration: none;
            margin-right: 5px;
        }

        .table-actions a:hover {
            text-decoration: underline;
        }
        </style>
</head>
<body>
<br><br><br><br>
<div class="container">
    <h1><strong>Информация на потребителите</strong></h1>
    <table class="table">
        <thead>
        <tr>
            <th>Име</th>
            <th>Имейл</th>
            <th>Парола</th>
            <th>Роля</th>
            <th>Действия</th>
        </tr>
        </thead>
        <tbody>
            <?php
            if ($users) {
                while ($row = mysqli_fetch_assoc($users)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['password']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['role']) . "</td>";
                    echo "<td class='table-actions'>";
                    echo "<a href='edit_user.php?id=" . $row['id'] . "'>Редактирай</a> | ";
                    echo "<a href='?action=delete&id=" . $row['id'] . "' onclick='return confirm(\"Сигурен ли си?\");'>Изтрий</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>
<script>
function editUser(userId) {
    // Redirect to the edit_user.php page with the user ID as a query parameter
    window.location.href = 'edit_user.php?id=' + userId;
}
</script>
</body>
</html>
<br><br><br><br>
<?php 
include("footer.php");
?>