<?php
include("database.php")
?>

<nav>
        <div class="nav_header">
            <div class="nav_logo">
                <a href="index.php"><img src="Images/LOGO.png" alt="logo"></a>
            </div>  
            <div class="nav_menu_btn" id="menu-btn">
                <span><i class="ri-menu-line"></i></span>
            </div>
       <!-- Примерен код -->
<ul class="nav_links" id="nav-links">
    <li class="link"><a href="Index.php">Начална страница</a></li>
    <li class="link"><a href="AdditivesPage.php">Хранителни добавки</a></li>
    <li class="link"><a href="DietPage.php">Диети</a></li>
    <li class="link"><a href="calcalculator.php">Калориен калкулатор</a></li>
    <li class="link"><a href="feedback.php"><button class="contactus-btn">Свържи се с нас</button></a></li>
    <li class="nav-item dropdown">

<!-- Въвеждаме логиката за показване на бутоните в зависимост от сесията на потребителя -->
<?php if(isset($_SESSION['user_id'])): ?>
    <!-- Ако потребителят е влязъл в системата -->
    <a class="nav-link_dropdown-toggle"  data-toggle="dropdown">
        <i class="far fa-user"></i>
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">        
        <a class="dropdown-item" href="logout.php">Отпиши се</a> <!-- Връзка за излизане -->
        <?php if($is_admin = true): ?>
            <div class="dropdown-divider"></div>
            <!-- Ако потребителят е администратор, показваме допълнителни опции -->
            <a class="dropdown-item" href="manage-users.php">Редактирай потребители</a>
            <a class="dropdown-item" href="fetchProducts.php">Редактирай продукти</a>
          
        <?php endif; ?>

    </div>
<?php else: ?>
    <!-- Ако потребителят не е влязъл в системата -->
    <a class="nav-link_dropdown-toggle"  data-toggle="dropdown">
        <i class="far fa-user"></i>
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="logreg.php">Впиши се</a> <!-- Връзка за влизане -->
        <div class="dropdown-divider"></div>
    </div>
<?php endif; ?>
        <i class="far fa-star" style="cursor: pointer;"></i>
    </li>  
</ul>
       </nav>
<form id="favoritesPopup" class="favorites-popup" style="display:none;" method="POST" action="updatePortfolio.php">
<?php
include("database.php");
$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

    $userId = $_SESSION['user_id'];
    // Removed the erroneous closing bracket ']'
    $sql = "SELECT diet, additives, calories FROM accounts WHERE id = '$userId'";
    $row = $conn->query($sql)->fetch_assoc();

    $diet = $row['diet'];
    $additive = $row['additives']; 
    $calories = $row['calories'];
?>
    <div class="popup-content">
        <span class="close">&times;</span>
        <h2>Твоето портфолио:</h2>
        <!-- Diet Section -->
        <div class="favorite-section" id="dietSection"  style="display: flex;">
            <h3 style="margin-right: 10px">Твоята диета:</h3>
            <div id="currentDiet"></div>
            <div id="currentDiet" style="margin-top:18px;"><?php echo isset($diet) ? htmlspecialchars($diet) : ''; ?></div>
            <button style="margin-left: 10px;" type="button" id="editDietButton" onclick="editDiet()">Промени</button>
            <div id="dietForm" style="display:none;">
                <select name="userDiet" id="userDiets" style="margin-top:18px; margin-left: 10px;">
                    <?php foreach ($diets as $diet): ?> <!-- Iterate over each diet -->
                        <option  value="<?php echo htmlspecialchars($diet); ?>"><?php echo htmlspecialchars($diet); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <!-- Additives Section -->
        <div class="favorite-section" id="additiveSection" style="display: flex;">  
            <h3 style="margin-right: 10px">Любима добавка:</h3>
            <div id="currentAdditive"></div>
            <div id="currentAdditive" style="margin-top:18px;"><?php echo isset($additive) ? htmlspecialchars($additive) : ''; ?></div>
            <button style="margin-left: 10px;" type="button" id="editAdditiveButton" onclick="editAdditive()">Промени</button>
            <div id="additiveForm" style="display:none;">
                <select name="userAdditive" id="userAdditives" style="margin-top:18px; margin-left: 10px;">
                    <?php foreach ($additives as $additive): ?>
                        <option value="<?php echo htmlspecialchars($additive); ?>"><?php echo htmlspecialchars($additive); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="favorite-section" style="display: flex;">
            <h3 style="margin-right: 10px">Твоите калории:</h3>
            <div id="userCalories" style="margin-top:18px;"><?php echo $calories; ?> калории</div>
        </div>
    </div>
    <button type="submit">Запази</button>
</form>

<script>
    var isLoggedIn = <?php echo isset($_SESSION['user_id']) ? 'true' : 'false'; ?>;
    document.querySelector('.fa-star').addEventListener('click', function() {
        if(isLoggedIn) {
            document.getElementById('favoritesPopup').style.display = 'block';
        } else {
            window.alert("За да продължите трябва да влезете в профила си.");
        }
    });

    document.querySelector('.favorites-popup .close').addEventListener('click', function() {
        document.getElementById('favoritesPopup').style.display = 'none';
    });

    function editDiet() {
    document.getElementById('currentDiet').style.display = 'none';
    document.getElementById('editDietButton').style.display = 'none';
    document.getElementById('dietForm').style.display = 'block';
}

function saveDiet() {
    const selectedDiet = document.getElementById('userDiets').value;
    const formData = new FormData();
    formData.append('diet', selectedDiet); // Ensure the key matches the one used in PHP

    fetch('updatePortfolio.php', { // Corrected to use 'fetch'
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('currentDiet').innerText = selectedDiet + ' калории';
        document.getElementById('dietForm').style.display = 'none';
        document.getElementById('editDietButton').style.display = 'block';
        document.getElementById('currentDiet').style.display = 'block';
    })
    .catch(error => console.error('Error:', error));
}

function editAdditive() {
    document.getElementById('currentAdditive').style.display = 'none';
    document.getElementById('editAdditiveButton').style.display = 'none';
    document.getElementById('additiveForm').style.display = 'block';
}

function saveAdditive() {
    const selectedAdditive = document.getElementById('userAdditives').value;
    const formData = new FormData();
    formData.append('userAdditive', selectedAdditive);
    
    fetch('updatePortfolio.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('currentAdditive').innerText = selectedAdditive;
        document.getElementById('additiveForm').style.display = 'none';
        document.getElementById('editAdditiveButton').style.display = 'block';
        document.getElementById('currentAdditive').style.display = 'block';
    })
    .catch(error => console.error('Error:', error));
}
</script>
    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="script.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>



<script src="assets/js/jquery.easing.min.js"></script>
<script src="assets/js/scrolling-nav.js"></script>
