<?php 
session_start();
include("database.php");
include("portfolio.php");
include("navbar.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link  href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js" rel="stylesheet"/>
  	<title>Sport Endurance</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="styleproduct.css">
    <link rel="stylesheet" href="comments.css">


    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>
          body{
    overflow-x: hidden;
  }
    </style>
</head>
<body>
    <br><br><br><br>
<?php
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$productId = $conn->real_escape_string($_GET['id']); // Примерен ID на продукта. Заменете с реален ID или метод за получаването му.

$stmt = mysqli_prepare($conn, "SELECT * FROM products WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $productId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    
    if ($row) {
        echo "<div class='container1'>";
        echo "<div class='image'  style='margin-right: 2%'><img src='Images/AdditivesPage/" . htmlspecialchars($row['productImage']) . "' alt='" . htmlspecialchars($row['productName']) . "' ></div>";
        echo "<div class='details'>";
        echo "<h2>" . htmlspecialchars($row['productName']) . "</h2>";
        echo "<p>" . htmlspecialchars($row['productDescription']) . "</p>";
        echo "<h3><strong>Употреба</strong></h3>";
        echo "<p>" . htmlspecialchars($row['productUsage']) . "</p>";
        // Тук може да добавите допълнителни секции като оценка и коментари
        echo "</div></div>";
    } else {
        echo "Няма намерен продукт.";
    }
} else {
    echo "Грешка при заявката.";
}

mysqli_stmt_close($stmt);
?>

<div class="rating" style="display: flex;">
    <h3>Рейтинг на продукт:</h3>
    <div class="product-studyRating" style="margin-left: 2%;">
        <h4>Изученост</h4>
        <p>Оценка: <?php echo htmlspecialchars($row['studyRating']); ?> / 5</p>
    </div>

    <div class="product-effectivenessRating" style="margin-left: 2%;">
        <h4>Ефективност</h4>    
        <p>Оценка: <?php echo htmlspecialchars($row['effectivenessRating']); ?> / 5</p>
    </div>
</div>  

<div class="comments"></div>

<script>
const comments_page_id = <?php echo $productId; ?>;

// Function to bind events to newly loaded comments and forms
function bindCommentEvents() {
    // Handle clicks on 'Write Comment' and 'Reply' buttons
    document.querySelectorAll(".comments .write_comment_btn, .comments .reply_comment_btn").forEach(element => {
        element.onclick = event => {
            event.preventDefault();
            document.querySelectorAll(".comments .write_comment").forEach(element => element.style.display = 'none');
            const formContainer = document.querySelector("div[data-comment-id='" + element.getAttribute("data-comment-id") + "']");
            if (formContainer) {
                formContainer.style.display = 'block';
                formContainer.querySelector("input[name='name']").focus();
            }
        };
    });

    // Handle form submissions
    document.querySelectorAll(".comments .write_comment form").forEach(element => {
        element.onsubmit = event => {
            event.preventDefault();
            const formData = new FormData(element);
            formData.append('page_id', comments_page_id); // Ensure page_id is included in the POST request

            fetch("comments.php?page_id=" + comments_page_id, {
                method: 'POST',
                body: formData
            }).then(response => response.text()).then(data => {
                element.parentElement.innerHTML = data;
                bindCommentEvents(); // Re-bind events to new content
            });
        };
    });
}

// Initial fetch to load comments
fetch("comments.php?page_id=" + comments_page_id)
    .then(response => response.text())
    .then(data => {
        document.querySelector(".comments").innerHTML = data;
        bindCommentEvents(); // Bind events after initial content load
    });
</script>
</body>
</html>
<?php 
include("footer.php");
?>