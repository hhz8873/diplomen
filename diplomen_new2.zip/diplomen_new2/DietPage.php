<?php
session_start();
include("database.php");
require("navbar.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css'>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" rel="stylesheet"/>
  	<title>Sport Endurance</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">

    <link rel="shortcut icon" href="Images/LOGO.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>
          body{
    overflow-x: hidden;
  }
    </style>
</head>
<body>
<br><br><br><br>
    <?php
// Establish database connection
$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch products of type 'additive'
$sql = "SELECT id, productName, productImage FROM products WHERE productType = 'diet'";
$result = mysqli_query($conn, $sql);

if (!$result) {
    echo "Error fetching products: " . mysqli_error($conn);
    mysqli_close($conn);
    exit;
}
?>

<section class="products">
    <?php while($row = mysqli_fetch_assoc($result)): ?>
        <article class="product">
            <img src="Images/DietPage/<?php echo htmlentities($row['productImage']); ?>" alt="<?php echo htmlentities($row['productName']); ?>">
            <h2 class="productcolor"><strong><?php echo htmlentities($row['productName']); ?></strong></h2>
            <a href="Diets.php?id=<?php echo $row['id']; ?>" class="btn">Научи повече!</a>
        </article>
    <?php endwhile; ?>
</section>

<?php
// Close database connection
mysqli_close($conn);
?>

    
    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="script.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.min.js"></script>

<script src="assets/js/jquery.easing.min.js"></script>
<script src="assets/js/scrolling-nav.js"></script>
</body>
</html>
<br><br><br><br><br><br><br><br>
<?php 
include("footer.php");
?>