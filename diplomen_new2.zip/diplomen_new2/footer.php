<footer id="footer" class="footer bg-dark text-white" style="border-radius:10px;">
  <div class="footer_container">
    <div class="row" style="justify-content: space-between;" >

      <!-- Column 1: Contact Info -->
      <div class="col-xs-12 col-sm-6 col-md-4" style="margin-top: 5%;">
        <div class="footer-logo">
          <button href="index.php" style="border:none; background: none;">
            <h3 style="color: #e91a1a;">Sport Endurance</h3>
          </button>
        </div>
        <div class="mt-4">
          <div class="social-icons" style="padding-left: 25%;">
            <a href="https://www.facebook.com/VSEEEplovdiv/" class="text-white mr-2"><i class="fab fa-facebook" style="color: #e91a1a;"></i></a>
            <a href="https://twitter.com/" class="text-white mr-2"><i class="fab fa-twitter" style="color: #e91a1a;"></i></a>
            <a href="https://www.instagram.com/pgee.plovdiv/" class="text-white mr-2"><i class="fab fa-instagram" style="color: #e91a1a;"></i></a>
            <a href="https://www.youtube.com/@pgee.plovdiv" class="text-white"><i class="fab fa-youtube" style="color: #e91a1a;"></i></a>
          </div>
        </div>
      </div>

          <!-- Column 3: Additional Contact Information -->
      <div class="col-xs-12 col-sm-6 col-md-4" style="margin-top: 5%;">
        <h4 class="module-title"><strong>Информация</strong></h4>
        <ul class="list-unstyled">
          <li class="media">
            <span class="fa-stack fa-lg mr-3" style="width:10px;">
              <i class="fas fa-map-marker-alt" style="color: #e91a1a;"></i>            
            </span>
            <div class="media-body">
              <p>Пловдив, България</p>
            </div>
          </li>
          <li class="media">
            <span class="fa-stack fa-lg mr-3" style="width: 10px;">
            <i class="fa-solid fa-phone" style="color: #e91a1a;"></i>            
        </span>
            <div class="media-body">
              <p>(359) 89 828 1912<br>(359) 89 727 1700</p>
            </div>
          </li>
          <li class="media">
            <span class="fa-stack fa-lg mr-3" style="width: 10px;">
            <i class="fa-solid fa-envelope" style="color: #e91a1a;"></i>            
        </span>
            <div class="media-body">
              <a href="mailto:info@sportendurance.com" class="text-white">info@sportendurance.com</a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>